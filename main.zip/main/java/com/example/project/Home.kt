package com.example.project

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
data class Book(val title: String, val imageResId: Int, val description: String)

class Home : AppCompatActivity() {
    val bookList = listOf(
        Book("The Hobbit", R.drawable.book1, "A fantasy novel by J.R.R. Tolkien."),
        Book("1984", R.drawable.book2, "A dystopian novel by George Orwell."),
        Book("Harry Potter", R.drawable.book3, "A magical journey by J.K. Rowling."),
        Book("The Great Gatsby", R.drawable.book4, "A story of the American dream, by F. Scott Fitzgerald."),
    Book("To Kill a Mockingbird", R.drawable.book5, "A novel about racial injustice by Harper Lee."),
    Book("Pride and Prejudice", R.drawable.book6, "A classic romance novel by Jane Austen."),
    Book("The Catcher in the Rye", R.drawable.book7, "A story of teenage rebellion by J.D. Salinger."),
    Book("Moby-Dick", R.drawable.book8, "A sailor’s obsession with hunting a white whale, by Herman Melville."),
    Book("The Alchemist", R.drawable.book9, "A philosophical novel by Paulo Coelho about following one’s dreams."),
    Book("The Da Vinci Code", R.drawable.book10, "A mystery thriller by Dan Brown, exploring secrets of history."),
    )


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_home, menu)
        return true
    }
    override fun onOptionsItemSelected(item: android.view.MenuItem): Boolean {
        return when (item.itemId) {

            R.id.action_my_ratings -> {
                val intent = Intent(this, MyRating::class.java)
                startActivity(intent)
                true
            }
            R.id.action_settings -> {
                val intent = Intent(this, setting::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        val userName = getSharedPreferences("user_prefs", MODE_PRIVATE)
            .getString("user_name", "User")

        findViewById<TextView>(R.id.welcomeTextView).text = "Welcome, $userName!"

        val bookContainer = findViewById<LinearLayout>(R.id.bookListContainer)


        for (book in bookList) {
            val item = layoutInflater.inflate(R.layout.activity_book_item_layout, null)

            val bookImage = item.findViewById<ImageView>(R.id.bookImage)
            val bookTitle = item.findViewById<TextView>(R.id.bookTitle)

            bookImage.setImageResource(book.imageResId)
            bookTitle.text = book.title

            item.setOnClickListener {
                val intent = Intent(this, BookDetail::class.java)
                intent.putExtra("title", book.title)
                intent.putExtra("description", book.description)
                intent.putExtra("imageResId", book.imageResId)
                startActivity(intent)
            }

            bookContainer.addView(item)
        }
    }
}