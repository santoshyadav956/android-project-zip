package com.example.project

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class splash : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)




        Handler(Looper.getMainLooper()).postDelayed({
            val sharedPref = getSharedPreferences("user_prefs", MODE_PRIVATE)
            val name = sharedPref.getString("user_name", null)
            val email = sharedPref.getString("user_email", null)

            if (name != null && email != null) {
                startActivity(Intent(this, Home::class.java))
            } else {
                startActivity(Intent(this, login::class.java))
            }
            finish()
        }, 3000)


    }
}
