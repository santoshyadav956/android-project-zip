package com.example.project

import android.content.Context
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RatingBar
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MyRating : AppCompatActivity() {
    private val bookList = listOf(
        Book("The Hobbit", R.drawable.book1, "A fantasy novel by J.R.R. Tolkien."),
        Book("1984", R.drawable.book2, "A dystopian novel by George Orwell."),
        Book("Harry Potter", R.drawable.book3, "A magical journey by J.K. Rowling."),
        Book("The Great Gatsby", R.drawable.book4, "A story of the American dream, by F. Scott Fitzgerald."),
        Book("To Kill a Mockingbird", R.drawable.book5, "A novel about racial injustice by Harper Lee."),
        Book("Pride and Prejudice", R.drawable.book6, "A classic romance novel by Jane Austen."),
        Book("The Catcher in the Rye", R.drawable.book7, "A story of teenage rebellion by J.D. Salinger."),
        Book("Moby-Dick", R.drawable.book8, "A sailor’s obsession with hunting a white whale, by Herman Melville."),
        Book("The Alchemist", R.drawable.book9, "A philosophical novel by Paulo Coelho about following one’s dreams."),
        Book("The Da Vinci Code", R.drawable.book10, "A mystery thriller by Dan Brown, exploring secrets of history."),

        )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_rating)

        val container = findViewById<LinearLayout>(R.id.ratingsContainer)
        val sharedPref = getSharedPreferences("ratings", Context.MODE_PRIVATE)

        for (book in bookList) {
            val userRating = sharedPref.getFloat(book.title, 0f)
            if (userRating > 0f) {
                val itemView = layoutInflater.inflate(R.layout.activity_rating_item_layout, null)

                val imageView = itemView.findViewById<ImageView>(R.id.ratedBookImage)
                val titleView = itemView.findViewById<TextView>(R.id.ratedBookTitle)
                val ratingBar = itemView.findViewById<RatingBar>(R.id.ratedBookRating)

                imageView.setImageResource(book.imageResId)
                titleView.text = book.title

                ratingBar.rating = userRating


                container.addView(itemView)
            }
        }
    }
}