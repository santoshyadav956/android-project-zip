package com.example.project

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class setting : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)

        val clearRatingsBtn = findViewById<Button>(R.id.btnClearRatings)
        val logoutBtn = findViewById<Button>(R.id.btnLogout)

        clearRatingsBtn.setOnClickListener {
            val ratingPrefs = getSharedPreferences("ratings", Context.MODE_PRIVATE)
            ratingPrefs.edit().clear().apply()

            Toast.makeText(this, "All ratings cleared!", Toast.LENGTH_SHORT).show()
        }

        logoutBtn.setOnClickListener {
            val loginPrefs = getSharedPreferences("login", Context.MODE_PRIVATE)
            loginPrefs.edit().clear().apply()

            Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show()

            // Navigate back to login
            val intent = Intent(this, login::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }
    }
}