package com.example.project

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class BookDetail : AppCompatActivity() {
    private lateinit var bookTitle: String
    private var imageResId: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_book_detail)
        val description = intent.getStringExtra("description") ?: ""

        findViewById<TextView>(R.id.bookDetailDescription).text = description

        bookTitle = intent.getStringExtra("title") ?: "Unknown Book"
        imageResId = intent.getIntExtra("imageResId", R.drawable.book1)

        findViewById<TextView>(R.id.bookDetailTitle).text = bookTitle
        findViewById<ImageView>(R.id.bookDetailImage).setImageResource(imageResId)

        val ratingBar = findViewById<RatingBar>(R.id.bookRatingBar)
        val saveButton = findViewById<Button>(R.id.saveRatingButton)

        val sharedPref = getSharedPreferences("ratings", Context.MODE_PRIVATE)
        ratingBar.rating = sharedPref.getFloat(bookTitle, 0f)

        saveButton.setOnClickListener {
            val rating = ratingBar.rating
            sharedPref.edit().putFloat(bookTitle, rating).apply()
            showCustomToast("Thanks! You rated \"$bookTitle\" $rating")
        }
    }

    private fun showCustomToast(message: String) {
        val inflater = layoutInflater
        val layout: View = inflater.inflate(R.layout.custom_toast_layout, null)

        val text: TextView = layout.findViewById(R.id.toastText)
        text.text = message

        val toast = Toast(applicationContext)
        toast.duration = Toast.LENGTH_SHORT
        toast.view = layout
        toast.show()
    }
}